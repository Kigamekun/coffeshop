from django.urls import path
from .views import *
from django.conf.urls import handler404,handler500
app_name = 'core'

urlpatterns = [
    path('', HomeView.as_view(), name='home'),
    path('update/<update_id>',update , name="update"),
    path('delete/<delete_id>',delete , name="delete"),
    path('about/',about,name="about"),
    path('detail/<detail_id>',detail,name="detail"),
    path('create/',create,name="create")
]


handler404 = 'core.views.handler404'

handler500 = 'core.views.handler500'

