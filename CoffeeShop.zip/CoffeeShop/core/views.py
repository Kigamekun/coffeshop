import random
import string

import stripe
from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.exceptions import ObjectDoesNotExist
from django.shortcuts import redirect
from django.shortcuts import render, get_object_or_404

from django.views.generic import ListView, DetailView, View


from .models import *
from .forms import *
# Create your views here.
def handler404(request, exception):

    context = {}
    response = render(request, "404.html", context=context)
    response.status_code = 404
    return response

def handler500(request, *args, **argv):
    context = {}
    response = render(request, "500.html", context=context)
    response.status_code = 500
    return response


@login_required
def create(request):
    forms = ItemForms(request.POST,request.FILES)
    if request.method == "POST":
        if forms.is_valid():
            forms.save()
            messages.success(request, 'Item Created.')
            return redirect('core:home')
        else :
            messages.success(request, 'Invalid add Item.')
            return redirect('core:create')
    context = {
		'forms':forms
	}
    return render(request,'create.html',context)
        

def about(request):
    return render(request,'about.html')
class HomeView(ListView):
    model = Item
    paginate_by = 3
    template_name = "home.html"


@login_required
def delete(request,delete_id):
    Item.objects.filter(id = delete_id).delete()
    messages.success(request,'Data Deleted')
    return redirect('core:home')


@login_required
def update(request,update_id):
	obj = Item.objects.get(id=update_id)
	data = {
	'name':obj.name,	
	'price':obj.price,
	'slug':obj.slug,
	'description':obj.description,
	'image':obj.image
	}

	forms = ItemForms(request.POST or None,request.FILES or None , initial= data,instance=obj)
	if request.method == 'POST':
		if forms.is_valid():
			messages.success(request, 'Data Updated.')
			forms.save()
			return redirect('core:home')
	context = {
	'page_title':'Update',
	'forms':forms,
	'obj':obj
	}
	return render(request,'create.html',context)


def detail(request,detail_id):
    data = Item.objects.get(id = detail_id)
    return render(request,'detail.html',{'data':data})
    
    